package FusionInventory::Agent::Task::Inventory::Linux::Archs;

use strict;
use warnings;

sub isEnabled {
    return 1;
}

sub doInventory {}

1;
