package win32::Job;

use strict;
use warnings;

1;
