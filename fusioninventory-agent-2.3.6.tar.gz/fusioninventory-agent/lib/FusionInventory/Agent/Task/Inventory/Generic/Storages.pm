package FusionInventory::Agent::Task::Inventory::Generic::Storages;

use strict;
use warnings;

sub isEnabled {
    return 1;
}

sub doInventory {}

1;
